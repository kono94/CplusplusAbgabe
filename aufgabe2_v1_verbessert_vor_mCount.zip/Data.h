template<class T>
class DataAufgabe1{
    class Data{
        Elem(T t,Elem* pNext = 0) : m_Content(t),m_pNext(pNext) {}
		T m_Content;
		Elem* m_pNext;
    }
    public:
        Data();
        Data(const Data& d);
        ~Data();
        Data& operator=(const Data& d);

        unsigned size() const;
        void insert(T t);
        void erase(T t);
        bool find(T t) const;
        Elem* findElem(T t) const;
        void print(unsigned max) const;

    private:
        Elem** look4(T t);
        Elem* m_pHead;

};
